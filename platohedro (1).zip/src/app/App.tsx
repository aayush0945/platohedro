import { useState } from "react";
import {
  ArrowUpRight,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  Play,
  Calendar,
  MapPin,
  Heart,
  CreditCard,
  Users,
  CheckCircle,
  ExternalLink,
} from "lucide-react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import logoImg from "@/imports/image.png";

// ─── PALETTE ──────────────────────────────────────────────────────────────────

const LIME    = "#99CC33";
const PINK    = "#FF46A2";
const CHARCOAL = "#1A1208";          // warm black, not cold
const SLATE   = "#3D3427";           // warm dark brown-grey
const MUTED   = "#7C6E62";           // warm muted, not blue-grey
const WHITE   = "#FFFFFF";
const CREAM   = "#F5EFE6";           // warm cream
const CREAM2  = "#EDE6DA";           // deeper cream for contrast
const LIME_WASH = "#EEF6D5";         // very soft lime
const PINK_WASH = "#FDE8F2";         // very soft pink
const BORDER  = "#DDD5C8";           // warm organic border
const LIME_DARK = "#5C7A1A";         // deep lime for text on light

// ─── DATA ────────────────────────────────────────────────────────────────────

const programs = [
  {
    id: 1,
    title: "Educación Artística Comunitaria",
    tag: "Niñes 8–18",
    desc: "Talleres semanales de artes plásticas, escultura y medios mixtos que construyen confianza creativa desde la raíz.",
    image: "https://images.unsplash.com/photo-1588072432836-e10032774350?w=700&h=500&fit=crop&auto=format",
  },
  {
    id: 2,
    title: "Laboratorio de Medios Digitales",
    tag: "Todas las edades",
    desc: "Fotografía, edición de video e ilustración digital con herramientas de nivel profesional, accesibles para todes.",
    image: "https://images.unsplash.com/photo-1603344797033-f0f4f587ab60?w=700&h=500&fit=crop&auto=format",
  },
  {
    id: 3,
    title: "Narrativas Colectivas",
    tag: "Jóvenes y adultes",
    desc: "Historia oral, fanzines y escritura narrativa que centra las voces del territorio y la memoria viva.",
    image: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=700&h=500&fit=crop&auto=format",
  },
  {
    id: 4,
    title: "Música y Producción Sonora",
    tag: "13+ años",
    desc: "Composición, producción de beats y grabación en estudio. Del barrio al escenario, con acompañamiento real.",
    image: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=700&h=500&fit=crop&auto=format",
  },
  {
    id: 5,
    title: "Residencias de Artes Visuales",
    tag: "Artistas",
    desc: "Residencias de seis semanas con espacio de estudio, mentoría y exposición colectiva de cierre.",
    image: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=700&h=500&fit=crop&auto=format",
  },
];

const quotes = [
  {
    text: "Platohedro me dio el lenguaje para decir lo que siempre sentí. Mi arte ahora tiene sentido — para mí y para mi comunidad.",
    author: "Valentina M.",
    role: "Participante, Educación Artística, 2023",
  },
  {
    text: "Llegué pensando que no tenía nada que decir. Me fui con un fanzine y una lectura en la biblioteca. Eso lo cambió todo.",
    author: "Andrés K.",
    role: "Participante, Narrativas Colectivas",
  },
  {
    text: "La residencia no solo me dio espacio de estudio. Me dio pares que me desafían y mentores que creen en el trabajo.",
    author: "Sienna R.",
    role: "Residencia de Artes Visuales, Primavera 2024",
  },
];

const events = [
  { date: { month: "AGO", day: "09" }, title: "Noche de Estudio Abierto", location: "Galería Principal, 3er Piso", time: "6:00 – 9:00 PM", tag: "Libre" },
  { date: { month: "AGO", day: "16" }, title: "Apertura: Exposición de Jóvenes Artistas", location: "Sala Comunal", time: "5:00 – 8:00 PM", tag: "Libre" },
  { date: { month: "AGO", day: "24" }, title: "Taller de Producción Sonora", location: "Estudio de Grabación B", time: "2:00 – 5:00 PM", tag: "Inscripción" },
  { date: { month: "SEP", day: "07" }, title: "Conversación con Artista en Residencia", location: "Sala de Conferencias, 2do Piso", time: "7:00 – 9:00 PM", tag: "Libre" },
  { date: { month: "SEP", day: "14" }, title: "Encuentro Anual de Comunidad", location: "Terraza Platohedro", time: "7:00 PM", tag: "Registro" },
];

const sponsors = [
  { name: "Ministerio de Cultura", full: "Ministerio de Cultura de Colombia" },
  { name: "Alcaldía de Medellín", full: "Alcaldía de Medellín" },
  { name: "Idartes", full: "Instituto Distrital de las Artes" },
  { name: "Colciencias", full: "Ministerio de Ciencia y Tecnología" },
  { name: "Redes", full: "Red Nacional de Cultura" },
  { name: "Open Society", full: "Open Society Foundations" },
];

const techInitiatives = [
  { icon: "🖥️", title: "Laboratorio de Acceso Digital", desc: "Acceso libre a computadores, Wi-Fi y talleres de alfabetización digital para integrantes de la comunidad." },
  { icon: "🎬", title: "Estudio de Cine y Podcast", desc: "Equipos de grabación de nivel profesional disponibles para residentes y participantes de programas." },
  { icon: "🤖", title: "Arte, IA y Conocimiento Libre", desc: "Sesiones mensuales para explorar críticamente las tecnologías emergentes desde prácticas artísticas y el Buen Conocer." },
];

const donorTiers = [
  { amount: "$50k", label: "Semilla", perks: "boletín, actualizaciones de eventos" },
  { amount: "$150k", label: "Raíz", perks: "Todo lo anterior + 2 entradas a eventos" },
  { amount: "$300k", label: "Árbol", perks: "Todo lo anterior + catálogo anual" },
  { amount: "$1M", label: "Bosque", perks: "Todo lo anterior + visita al estudio y encuentro con artistas" },
];

// ─── ORGANIC BLOB ─────────────────────────────────────────────────────────────

function Blob({ color, style }: { color: string; style?: React.CSSProperties }) {
  return (
    <div
      className="absolute pointer-events-none"
      style={{
        borderRadius: "62% 38% 46% 54% / 60% 44% 56% 40%",
        filter: "blur(48px)",
        opacity: 0.55,
        backgroundColor: color,
        ...style,
      }}
    />
  );
}

// ─── COMPONENT ───────────────────────────────────────────────────────────────

export default function App() {
  const [navOpen, setNavOpen] = useState(false);
  const [carouselIndex, setCarouselIndex] = useState(0);
  const [quoteIndex, setQuoteIndex] = useState(0);
  const [selectedTier, setSelectedTier] = useState(1);
  const [customAmount, setCustomAmount] = useState("");
  const [donateStep, setDonateStep] = useState(1);

  const prevProgram = () => setCarouselIndex((i) => (i === 0 ? programs.length - 1 : i - 1));
  const nextProgram = () => setCarouselIndex((i) => (i === programs.length - 1 ? 0 : i + 1));
  const prevQuote = () => setQuoteIndex((i) => (i === 0 ? quotes.length - 1 : i - 1));
  const nextQuote = () => setQuoteIndex((i) => (i === quotes.length - 1 ? 0 : i + 1));

  return (
    <div className="min-h-screen overflow-x-hidden" style={{ backgroundColor: WHITE, color: CHARCOAL, fontFamily: "'Instrument Sans', sans-serif" }}>

      {/* ── TOP ACCENT BAND ── */}
      <div className="h-[3px]" style={{ background: `linear-gradient(to right, ${LIME}, ${CREAM2}, ${PINK})` }} />

      {/* ══════════════════════════════════════════════════════
          NAV
      ══════════════════════════════════════════════════════ */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl"
        style={{
          backgroundColor: "rgba(255,255,255,0.95)",
          borderBottom: `1px solid ${BORDER}`,
          boxShadow: "0 2px 24px rgba(26,18,8,0.06)",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-10 flex items-center justify-between h-16">
          <a href="#" className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 overflow-hidden rounded-xl flex items-center justify-center p-1" style={{ backgroundColor: "#7dcfca" }}>
              <ImageWithFallback src={logoImg} alt="Platohedro" className="w-full h-full object-contain" />
            </div>
            <span className="text-sm font-bold tracking-widest uppercase" style={{ color: CHARCOAL, fontFamily: "'DM Mono', monospace" }}>
              Platohedro
            </span>
          </a>

          <nav className="hidden lg:flex items-center gap-1">
            {[["Educación", "#programs"], ["Residencias", "#residencies"], ["Tecnología", "#technology"], ["Tienda / Galería", "#shop"]].map(([label, href]) => (
              <a
                key={label}
                href={href}
                className="relative px-4 py-2 text-sm font-medium transition-all duration-200 rounded-lg group"
                style={{ color: MUTED }}
              >
                {label}
                <span
                  className="absolute bottom-1 left-4 right-4 h-[2px] rounded-full scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"
                  style={{ background: `linear-gradient(to right, ${LIME}, ${PINK})` }}
                />
              </a>
            ))}
          </nav>

          <div className="hidden lg:flex items-center gap-3">
            <a
              href="#donate"
              className="group flex items-center gap-2 px-5 py-2.5 text-sm font-bold rounded-full transition-all duration-200 hover:scale-[1.04]"
              style={{
                backgroundColor: LIME,
                color: CHARCOAL,
                boxShadow: `0 2px 16px rgba(153,204,51,0.35)`,
              }}
            >
              <Heart size={14} style={{ color: PINK }} className="group-hover:scale-110 transition-transform" />
              Apoyar
            </a>
          </div>

          <button className="lg:hidden" onClick={() => setNavOpen(!navOpen)} style={{ color: CHARCOAL }}>
            {navOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {navOpen && (
          <div className="lg:hidden px-6 py-6 space-y-4" style={{ backgroundColor: CREAM, borderTop: `1px solid ${BORDER}` }}>
            {[["Educación", "#programs"], ["Residencias", "#residencies"], ["Tecnología", "#technology"], ["Tienda / Galería", "#shop"]].map(([label, href]) => (
              <a key={label} href={href} className="block text-sm font-medium py-1" style={{ color: SLATE }} onClick={() => setNavOpen(false)}>{label}</a>
            ))}
            <a href="#donate" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold" style={{ backgroundColor: LIME, color: CHARCOAL }} onClick={() => setNavOpen(false)}>
              <Heart size={14} style={{ color: PINK }} /> Apoyar
            </a>
          </div>
        )}
      </header>


      {/* ══════════════════════════════════════════════════════
          HERO — WHITE + ORGANIC LIME & PINK BLOBS
      ══════════════════════════════════════════════════════ */}
      <section className="relative overflow-hidden" style={{ backgroundColor: WHITE }}>

        {/* Organic ambient blobs */}
        <Blob color={`${LIME}50`} style={{ width: 520, height: 420, top: -80, right: -120, transform: "rotate(-15deg)" }} />
        <Blob color={`${PINK}30`} style={{ width: 380, height: 320, bottom: -60, left: -80, transform: "rotate(20deg)" }} />
        <Blob color={`${CREAM}CC`} style={{ width: 300, height: 260, top: "40%", right: "30%", transform: "rotate(5deg)" }} />

        {/* Copy block */}
        <div className="relative z-10 max-w-6xl mx-auto px-6 md:px-12 pt-32 md:pt-44 pb-16 md:pb-20 text-center">

          {/* Eyebrow */}
          <div className="inline-flex items-center gap-3 mb-10 px-5 py-2 rounded-full" style={{ backgroundColor: CREAM2, border: `1px solid ${BORDER}` }}>
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: LIME }} />
            <span className="text-xs tracking-[0.22em] uppercase font-medium" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>
              Medellín · Colombia · Desde 2004
            </span>
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: PINK }} />
          </div>

          {/* Headline */}
          <h1
            className="mx-auto mb-8"
            style={{
              fontFamily: "'DM Serif Display', serif",
              fontSize: "clamp(3.2rem, 8.5vw, 8.5rem)",
              lineHeight: 0.92,
              letterSpacing: "-0.03em",
              color: CHARCOAL,
              maxWidth: "920px",
            }}
          >
            Buen Vivir,<br />
            Buen{" "}
            <span style={{ color: LIME, fontStyle: "italic" }}>Conocer.</span>
          </h1>

          <p className="mx-auto mb-12" style={{ maxWidth: "560px", color: MUTED, fontSize: "1.125rem", lineHeight: 1.8 }}>
            Somos una organización cultural en Medellín que trabaja desde el arte, la tecnología y la educación para transformar vidas, tejer comunidad y construir soberanía del conocimiento — desde 2004.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-4 mb-20">
            <a
              href="#programs"
              className="group inline-flex items-center gap-2 px-8 py-4 font-bold rounded-full transition-all duration-200 hover:scale-[1.04]"
              style={{ backgroundColor: LIME, color: CHARCOAL, fontSize: "0.875rem", boxShadow: `0 4px 24px rgba(153,204,51,0.38)` }}
            >
              Explorar programas
              <ArrowUpRight size={15} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>
            <a
              href="#donate"
              className="inline-flex items-center gap-2 px-8 py-4 font-semibold rounded-full border-2 transition-all duration-200 hover:bg-pink-50"
              style={{ borderColor: PINK, color: PINK, fontSize: "0.875rem" }}
            >
              <Heart size={15} />
              Apoyar el proceso
            </a>
          </div>

          {/* Dashboard mockup */}
          <div
            className="relative mx-auto rounded-3xl overflow-hidden"
            style={{
              maxWidth: "960px",
              border: `1px solid ${BORDER}`,
              boxShadow: `0 4px 8px rgba(26,18,8,0.04), 0 16px 48px rgba(26,18,8,0.08), 0 48px 96px rgba(26,18,8,0.05)`,
            }}
          >
            {/* Browser chrome — warm cream */}
            <div className="flex items-center gap-2 px-5 py-3.5" style={{ backgroundColor: CREAM2, borderBottom: `1px solid ${BORDER}` }}>
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: PINK, opacity: 0.5 }} />
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: LIME, opacity: 0.5 }} />
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: BORDER }} />
              <div
                className="flex-1 mx-4 rounded-lg px-4 py-1.5 text-xs text-center"
                style={{ backgroundColor: CREAM, color: MUTED, fontFamily: "'DM Mono', monospace", maxWidth: "280px", margin: "0 auto" }}
              >
                platohedro.org
              </div>
            </div>

            {/* Dashboard body */}
            <div className="flex" style={{ backgroundColor: WHITE, minHeight: "480px" }}>

              {/* Sidebar — warm cream */}
              <div className="hidden md:flex flex-col gap-1 py-6 px-4 shrink-0" style={{ width: "200px", backgroundColor: CREAM, borderRight: `1px solid ${BORDER}` }}>
                <div className="flex items-center gap-2.5 px-3 py-2 mb-4">
                  <div className="w-6 h-6 rounded-lg overflow-hidden" style={{ backgroundColor: "#7dcfca" }}>
                    <ImageWithFallback src={logoImg} alt="logo" className="w-full h-full object-contain" />
                  </div>
                  <span className="text-xs font-bold tracking-widest uppercase" style={{ color: CHARCOAL, fontFamily: "'DM Mono', monospace" }}>Platohedro</span>
                </div>
                {[
                  ["Buen Vivir", true],
                  ["Educación", false],
                  ["Residencias", false],
                  ["Tecnología", false],
                  ["Territorio", false],
                ].map(([label, active]) => (
                  <div
                    key={label as string}
                    className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium"
                    style={{
                      backgroundColor: active ? `${LIME}22` : "transparent",
                      color: active ? LIME_DARK : MUTED,
                      borderLeft: active ? `2px solid ${LIME}` : "2px solid transparent",
                      fontFamily: "'DM Mono', monospace",
                    }}
                  >
                    <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: active ? LIME : BORDER }} />
                    {label}
                  </div>
                ))}
                <div className="mt-auto pt-6" style={{ borderTop: `1px solid ${BORDER}` }}>
                  <div className="flex items-center gap-2 px-3 py-2">
                    <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ backgroundColor: PINK }}>A</div>
                    <div>
                      <div className="text-xs font-medium" style={{ color: CHARCOAL }}>Admin</div>
                      <div className="text-xs" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>2026</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Main content */}
              <div className="flex-1 p-6 overflow-hidden">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <div className="text-xs" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>JULIO 2026 · MEDELLÍN</div>
                    <div className="font-semibold" style={{ color: CHARCOAL, fontFamily: "'DM Serif Display', serif", fontSize: "1.1rem" }}>Tejido comunitario</div>
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium" style={{ backgroundColor: `${LIME}22`, color: LIME_DARK, fontFamily: "'DM Mono', monospace" }}>
                    <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: LIME }} />
                    Proceso vivo
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 mb-5">
                  {[
                    { label: "Niñes y jóvenes", value: "432", note: "proyectado 2026", accent: LIME },
                    { label: "Residencias totales", value: "287", note: "desde 2004", accent: PINK },
                    { label: "Madres en proceso", value: "79", note: "proyectado 2026", accent: LIME },
                  ].map((stat) => (
                    <div key={stat.label} className="rounded-2xl p-4" style={{ backgroundColor: CREAM, border: `1px solid ${BORDER}` }}>
                      <div className="text-xs mb-2" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>{stat.label}</div>
                      <div className="font-bold mb-1" style={{ color: stat.accent, fontFamily: "'DM Serif Display', serif", fontSize: "1.4rem" }}>{stat.value}</div>
                      <div className="text-xs" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>{stat.note}</div>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-5 gap-3">
                  <div className="col-span-3 rounded-2xl p-4" style={{ backgroundColor: CREAM, border: `1px solid ${BORDER}` }}>
                    <div className="flex items-center justify-between mb-4">
                      <div className="text-xs font-semibold" style={{ color: CHARCOAL, fontFamily: "'DM Mono', monospace" }}>Procesos por área · Buen Conocer</div>
                      <div className="text-xs" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>2026</div>
                    </div>
                    <div className="flex items-end gap-2.5 h-28">
                      {[
                        { h: "78%", label: "Arte", lime: true },
                        { h: "55%", label: "Tecno.", lime: false },
                        { h: "90%", label: "Educ.", lime: true },
                        { h: "42%", label: "Mem.", lime: false },
                        { h: "65%", label: "Terr.", lime: true },
                        { h: "48%", label: "Sonido", lime: false },
                      ].map((bar, i) => (
                        <div key={i} className="flex-1 flex flex-col items-center gap-1">
                          <div className="w-full rounded-lg" style={{ height: bar.h, backgroundColor: bar.lime ? LIME : CREAM2, minHeight: "8px" }} />
                          <div style={{ color: MUTED, fontFamily: "'DM Mono', monospace", fontSize: "0.58rem" }}>{bar.label}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="col-span-2 rounded-2xl p-4 flex flex-col" style={{ backgroundColor: CREAM, border: `1px solid ${BORDER}` }}>
                    <div className="text-xs font-semibold mb-4" style={{ color: CHARCOAL, fontFamily: "'DM Mono', monospace" }}>Tejido reciente</div>
                    <div className="space-y-3 flex-1">
                      {[
                        { dot: LIME, text: "Taller de serigrafía — 14 niñes", time: "hoy" },
                        { dot: PINK, text: "Nueva residencia — Artes Visuales", time: "1d" },
                        { dot: LIME, text: "Encuentro de saberes — Territorio", time: "2d" },
                        { dot: BORDER, text: "Fanzine anual · convocatoria abierta", time: "4d" },
                      ].map((item, i) => (
                        <div key={i} className="flex items-start gap-2.5">
                          <div className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: item.dot }} />
                          <div>
                            <div className="text-xs leading-snug" style={{ color: CHARCOAL }}>{item.text}</div>
                            <div className="text-xs" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>{item.time}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-3 text-xs font-medium text-center py-1.5 rounded-lg" style={{ color: LIME_DARK, backgroundColor: `${LIME}18`, fontFamily: "'DM Mono', monospace" }}>
                      Ver todos los procesos →
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <p className="mt-5 text-xs" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>
            Panel de tejido comunitario · Buen Conocer · Platohedro 2026
          </p>
        </div>

        {/* Stats row */}
        <div style={{ borderTop: `1px solid ${BORDER}` }}>
          <div className="max-w-6xl mx-auto px-6 md:px-12 py-10 grid grid-cols-2 md:grid-cols-4 gap-px" style={{ backgroundColor: BORDER }}>
            {[
              ["432", "Niñes y jóvenes en proceso creativo", LIME],
              ["79", "Madres tejiendo conocimiento", PINK],
              ["287", "Residencias de Buen Conocer", LIME],
              ["22 años", "De Buen Vivir en Medellín", PINK],
            ].map(([num, label, color]) => (
              <div key={label} className="flex flex-col items-center justify-center py-8 px-6 text-center" style={{ backgroundColor: CREAM }}>
                <div className="font-bold mb-2" style={{ fontFamily: "'DM Serif Display', serif", fontSize: "clamp(1.75rem,3vw,2.5rem)", color: color as string }}>
                  {num}
                </div>
                <div className="text-xs" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>


      {/* ══════════════════════════════════════════════════════
          QUOTES — PINK WASH + ORGANIC BLOBS
      ══════════════════════════════════════════════════════ */}
      <section className="relative overflow-hidden py-28 px-6 md:px-10" style={{ background: `linear-gradient(160deg, ${PINK_WASH} 0%, ${WHITE} 60%, ${CREAM} 100%)` }}>
        <Blob color={`${PINK}28`} style={{ width: 380, height: 300, top: -60, right: -60, transform: "rotate(-10deg)" }} />
        <Blob color={`${LIME}20`} style={{ width: 280, height: 220, bottom: -40, left: -40, transform: "rotate(15deg)" }} />

        <div className="max-w-4xl mx-auto text-center relative z-10">
          {/* Pink badge */}
          <span
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold tracking-widest uppercase mb-10"
            style={{ backgroundColor: PINK, color: WHITE, fontFamily: "'DM Mono', monospace" }}
          >
            ♥ En sus palabras
          </span>

          <div className="relative min-h-[160px] flex flex-col items-center justify-center">
            <div className="w-px h-10 mb-6 rounded-full" style={{ background: `linear-gradient(to bottom, ${PINK}, transparent)` }} />
            <blockquote
              key={quoteIndex}
              className="text-xl md:text-2xl leading-relaxed italic mb-8 px-4"
              style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}
            >
              "{quotes[quoteIndex].text}"
            </blockquote>
            <div className="flex items-center gap-3">
              <div className="w-8 h-px rounded-full" style={{ backgroundColor: LIME }} />
              <div>
                <div className="text-sm font-bold" style={{ color: LIME_DARK }}>{quotes[quoteIndex].author}</div>
                <div className="text-xs mt-0.5" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>{quotes[quoteIndex].role}</div>
              </div>
              <div className="w-8 h-px rounded-full" style={{ backgroundColor: LIME }} />
            </div>
          </div>

          <div className="flex items-center justify-center gap-4 mt-10">
            <button onClick={prevQuote} className="w-9 h-9 rounded-full flex items-center justify-center transition-all hover:scale-110" style={{ border: `1px solid ${BORDER}`, color: MUTED, backgroundColor: WHITE }}>
              <ChevronLeft size={16} />
            </button>
            <div className="flex gap-2">
              {quotes.map((_, i) => (
                <button key={i} onClick={() => setQuoteIndex(i)} className="rounded-full transition-all" style={{ width: i === quoteIndex ? "20px" : "8px", height: "8px", backgroundColor: i === quoteIndex ? PINK : BORDER }} />
              ))}
            </div>
            <button onClick={nextQuote} className="w-9 h-9 rounded-full flex items-center justify-center transition-all hover:scale-110" style={{ border: `1px solid ${BORDER}`, color: MUTED, backgroundColor: WHITE }}>
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </section>


      {/* ══════════════════════════════════════════════════════
          EDUCACIÓN — WHITE
      ══════════════════════════════════════════════════════ */}
      <section id="programs" className="py-24 px-6 md:px-10 relative overflow-hidden" style={{ backgroundColor: WHITE, borderTop: `1px solid ${BORDER}` }}>
        <Blob color={`${LIME}18`} style={{ width: 320, height: 260, top: -40, right: -40, transform: "rotate(8deg)" }} />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div>
              <span
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase mb-4"
                style={{ backgroundColor: LIME, color: CHARCOAL, fontFamily: "'DM Mono', monospace" }}
              >
                Educación
              </span>
              <h2 className="text-4xl md:text-5xl font-bold" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>
                Lo que ofrecemos
              </h2>
            </div>
            <div className="flex items-center gap-3">
              <button onClick={prevProgram} className="w-10 h-10 rounded-xl border flex items-center justify-center transition-all hover:scale-105" style={{ borderColor: BORDER, color: MUTED, backgroundColor: CREAM }}>
                <ChevronLeft size={18} />
              </button>
              <span className="text-xs" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>{carouselIndex + 1} / {programs.length}</span>
              <button onClick={nextProgram} className="w-10 h-10 rounded-xl border flex items-center justify-center transition-all hover:scale-105" style={{ borderColor: BORDER, color: MUTED, backgroundColor: CREAM }}>
                <ChevronRight size={18} />
              </button>
            </div>
          </div>

          {/* Desktop grid */}
          <div className="hidden md:grid grid-cols-5 gap-4">
            {programs.map((prog, i) => (
              <div
                key={prog.id}
                className="group rounded-3xl overflow-hidden flex flex-col cursor-pointer transition-all duration-300 hover:-translate-y-2"
                style={{
                  backgroundColor: WHITE,
                  border: `2px solid ${i === carouselIndex ? LIME : BORDER}`,
                  boxShadow: i === carouselIndex ? `0 8px 32px rgba(153,204,51,0.22)` : `0 2px 12px rgba(26,18,8,0.06)`,
                }}
                onClick={() => setCarouselIndex(i)}
              >
                <div className="relative overflow-hidden aspect-[3/4]">
                  <img src={prog.image} alt={prog.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  <div className="absolute top-3 left-3 px-2.5 py-1 text-xs font-bold rounded-full" style={{ backgroundColor: PINK, color: WHITE, fontFamily: "'DM Mono', monospace" }}>
                    {prog.tag}
                  </div>
                </div>
                <div className="p-4 flex-1 flex flex-col" style={{ backgroundColor: i === carouselIndex ? LIME_WASH : WHITE }}>
                  <h3 className="text-sm font-bold mb-2 leading-tight" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>
                    {prog.title}
                  </h3>
                  <p className="text-xs leading-relaxed flex-1" style={{ color: MUTED }}>{prog.desc}</p>
                  <button className="mt-4 flex items-center gap-1 text-xs font-bold" style={{ color: LIME_DARK }}>
                    Saber más <ArrowUpRight size={12} />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Mobile */}
          <div className="md:hidden">
            <div className="rounded-3xl overflow-hidden" style={{ border: `1px solid ${BORDER}`, boxShadow: `0 4px 24px rgba(26,18,8,0.08)` }}>
              <div className="relative aspect-[4/3]">
                <img src={programs[carouselIndex].image} alt={programs[carouselIndex].title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <div className="absolute top-4 left-4 px-2.5 py-1 text-xs font-bold rounded-full" style={{ backgroundColor: PINK, color: WHITE }}>
                  {programs[carouselIndex].tag}
                </div>
              </div>
              <div className="p-6" style={{ backgroundColor: LIME_WASH }}>
                <h3 className="text-2xl font-bold mb-3" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>{programs[carouselIndex].title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: MUTED }}>{programs[carouselIndex].desc}</p>
                <button className="mt-4 flex items-center gap-1 text-sm font-bold" style={{ color: LIME_DARK }}>
                  Saber más <ArrowUpRight size={14} />
                </button>
              </div>
            </div>
            <div className="flex gap-2 justify-center mt-4">
              {programs.map((_, i) => (
                <button key={i} onClick={() => setCarouselIndex(i)} className="rounded-full transition-all" style={{ width: i === carouselIndex ? "20px" : "8px", height: "8px", backgroundColor: i === carouselIndex ? LIME : BORDER }} />
              ))}
            </div>
          </div>

          <div className="mt-10 text-center">
            <a href="#" className="inline-flex items-center gap-2 px-7 py-3.5 text-sm font-bold rounded-full border-2 transition-all duration-200 hover:bg-lime-50" style={{ borderColor: LIME, color: LIME_DARK }}>
              Ver todos los programas <ArrowUpRight size={16} />
            </a>
          </div>
        </div>
      </section>


      {/* ══════════════════════════════════════════════════════
          RESIDENCIAS — SOFT LIME WASH
      ══════════════════════════════════════════════════════ */}
      <section id="residencies" className="relative overflow-hidden py-24 px-6 md:px-10" style={{ background: `linear-gradient(150deg, ${LIME_WASH} 0%, ${WHITE} 70%)`, borderTop: `1px solid ${BORDER}` }}>
        <Blob color={`${LIME}30`} style={{ width: 420, height: 340, top: -80, left: -80, transform: "rotate(-20deg)" }} />
        <Blob color={`${PINK}18`} style={{ width: 260, height: 200, bottom: 0, right: -40, transform: "rotate(10deg)" }} />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-end justify-between mb-12">
            <div>
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase mb-4" style={{ backgroundColor: PINK, color: WHITE, fontFamily: "'DM Mono', monospace" }}>
                Residencias
              </span>
              <h2 className="text-4xl md:text-5xl font-bold" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>
                Espacio para crear<br />
                <span className="italic" style={{ color: PINK }}>desde adentro.</span>
              </h2>
            </div>
            <a href="#" className="hidden md:flex items-center gap-2 text-sm font-medium" style={{ color: MUTED }}>
              Ver convocatorias <ArrowUpRight size={14} />
            </a>
          </div>

          {/* Featured */}
          <div className="grid grid-cols-1 lg:grid-cols-2 rounded-3xl overflow-hidden mb-6" style={{ border: `1px solid ${BORDER}`, boxShadow: `0 8px 40px rgba(26,18,8,0.08)` }}>
            <div className="relative overflow-hidden aspect-[4/3] lg:aspect-auto min-h-[320px]">
              <img src="https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=800&h=600&fit=crop&auto=format" alt="Artista en residencia" className="w-full h-full object-cover" />
              <div className="absolute inset-0" style={{ background: `linear-gradient(to top, rgba(26,18,8,0.5), transparent)` }} />
              <span className="absolute top-5 left-5 px-3 py-1.5 text-xs font-bold rounded-full" style={{ backgroundColor: PINK, color: WHITE }}>
                Convocatoria abierta
              </span>
            </div>
            <div className="p-8 md:p-12 flex flex-col justify-center" style={{ backgroundColor: WHITE }}>
              <span className="text-xs font-bold tracking-widest uppercase mb-4" style={{ color: PINK, fontFamily: "'DM Mono', monospace" }}>
                Residencia Principal · 6 semanas
              </span>
              <h3 className="text-3xl font-bold mb-4 leading-tight" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>
                Residencia de Artes Visuales y Medios
              </h3>
              <p className="text-sm leading-relaxed mb-6" style={{ color: MUTED }}>
                Seis semanas de inmersión creativa con espacio de estudio propio, mentoría semanal, acceso a todos los laboratorios y una exposición colectiva de cierre abierta a la comunidad.
              </p>
              <div className="grid grid-cols-2 gap-3 mb-8">
                {[["6", "Semanas de duración"], ["4", "Artistas por cohorte"], ["Libre", "Acceso a laboratorios"], ["2004", "Primera residencia"]].map(([val, label]) => (
                  <div key={label} className="rounded-2xl p-3" style={{ backgroundColor: LIME_WASH, border: `1px solid ${BORDER}` }}>
                    <div className="text-lg font-bold mb-0.5" style={{ fontFamily: "'DM Serif Display', serif", color: LIME_DARK }}>{val}</div>
                    <div className="text-xs" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>{label}</div>
                  </div>
                ))}
              </div>
              <a href="#" className="group inline-flex items-center gap-2 px-6 py-3 text-sm font-bold rounded-full w-fit transition-all hover:scale-[1.03]" style={{ backgroundColor: LIME, color: CHARCOAL, boxShadow: `0 4px 16px rgba(153,204,51,0.3)` }}>
                Aplicar ahora <ArrowUpRight size={16} />
              </a>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { title: "Residencia de Investigación", tag: "3 semanas", desc: "Para investigadores, teóricos y curadores que quieren trabajar en el cruce entre arte, territorio y conocimiento.", image: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&h=400&fit=crop&auto=format" },
              { title: "Residencia Sonora", tag: "4 semanas", desc: "Producción, composición y experimentación sonora en el estudio de grabación.", image: "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=600&h=400&fit=crop&auto=format" },
              { title: "Residencia Comunitaria", tag: "8 semanas", desc: "Proceso de co-creación con comunidades del barrio. Arte situado, memoria colectiva y transformación desde el territorio.", image: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600&h=400&fit=crop&auto=format" },
            ].map((res) => (
              <article key={res.title} className="group rounded-3xl overflow-hidden flex flex-col cursor-pointer transition-all duration-300 hover:-translate-y-1" style={{ backgroundColor: WHITE, border: `1px solid ${BORDER}`, boxShadow: `0 2px 12px rgba(26,18,8,0.05)` }}>
                <div className="overflow-hidden aspect-[16/9] relative">
                  <img src={res.image} alt={res.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                  <div className="absolute top-3 left-3 px-2.5 py-1 text-xs font-bold rounded-full" style={{ backgroundColor: PINK, color: WHITE }}>
                    {res.tag}
                  </div>
                </div>
                <div className="p-5 flex-1 flex flex-col">
                  <h3 className="font-bold mb-2" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>{res.title}</h3>
                  <p className="text-xs leading-relaxed flex-1" style={{ color: MUTED }}>{res.desc}</p>
                  <button className="mt-4 flex items-center gap-1 text-xs font-bold" style={{ color: LIME_DARK }}>
                    Saber más <ArrowUpRight size={12} />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>


      {/* ══════════════════════════════════════════════════════
          TECNOLOGÍA — CREAM
      ══════════════════════════════════════════════════════ */}
      <section id="technology" className="relative overflow-hidden py-24 px-6 md:px-10" style={{ background: `linear-gradient(140deg, ${CREAM} 0%, ${WHITE} 60%)`, borderTop: `1px solid ${BORDER}` }}>
        <Blob color={`${PINK}20`} style={{ width: 360, height: 300, top: -60, right: 80, transform: "rotate(-5deg)" }} />

        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center relative z-10">
          <div>
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase mb-4" style={{ backgroundColor: LIME, color: CHARCOAL, fontFamily: "'DM Mono', monospace" }}>
              Tecnología
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-6" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>
              Herramientas creativas<br />
              <span className="italic" style={{ color: PINK }}>para todas las personas.</span>
            </h2>
            <p className="leading-relaxed mb-10 max-w-md" style={{ color: MUTED }}>
              El acceso a la tecnología creativa no puede depender del ingreso económico. Nuestros laboratorios digitales y estudios de medios están abiertos a toda la comunidad, de forma libre y gratuita, bajo principios de Buen Conocer.
            </p>

            <div className="space-y-4">
              {techInitiatives.map((item, i) => (
                <div
                  key={item.title}
                  className="group flex gap-4 p-5 rounded-2xl transition-all duration-200 hover:shadow-md cursor-pointer"
                  style={{
                    backgroundColor: WHITE,
                    border: `1px solid ${BORDER}`,
                    borderLeft: `4px solid ${i % 2 === 0 ? LIME : PINK}`,
                  }}
                >
                  <div className="text-xl shrink-0 w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: i % 2 === 0 ? LIME_WASH : PINK_WASH }}>
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="font-bold mb-1" style={{ color: CHARCOAL, fontFamily: "'DM Serif Display', serif" }}>{item.title}</h3>
                    <p className="text-sm leading-relaxed" style={{ color: MUTED }}>{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <a href="#" className="mt-8 inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold rounded-full border transition-all hover:scale-[1.02]" style={{ borderColor: BORDER, color: SLATE, backgroundColor: WHITE }}>
              Reservar tiempo en estudio <ExternalLink size={14} />
            </a>
          </div>

          <div className="relative">
            <div className="rounded-3xl overflow-hidden" style={{ border: `1px solid ${BORDER}`, boxShadow: `0 12px 48px rgba(26,18,8,0.1)` }}>
              <img src="https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?w=800&h=800&fit=crop&auto=format" alt="Laboratorio digital de Platohedro" className="w-full h-full object-cover aspect-square" />
            </div>
            <div className="absolute -bottom-5 -left-5 rounded-2xl px-6 py-4 hidden md:block" style={{ backgroundColor: LIME, boxShadow: `0 4px 20px rgba(153,204,51,0.35)` }}>
              <div className="text-2xl font-bold" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>340+</div>
              <div className="text-xs mt-0.5" style={{ color: LIME_DARK, fontFamily: "'DM Mono', monospace" }}>Sesiones en lab / mes</div>
            </div>
          </div>
        </div>
      </section>


      {/* ══════════════════════════════════════════════════════
          TIENDA — PINK WASH
      ══════════════════════════════════════════════════════ */}
      <section id="shop" className="relative overflow-hidden py-24 px-6 md:px-10" style={{ background: `linear-gradient(160deg, ${PINK_WASH} 0%, ${WHITE} 65%)`, borderTop: `1px solid ${BORDER}` }}>
        <Blob color={`${PINK}28`} style={{ width: 400, height: 320, top: -60, right: -60, transform: "rotate(-8deg)" }} />
        <Blob color={`${LIME}14`} style={{ width: 240, height: 200, bottom: 0, left: 60, transform: "rotate(12deg)" }} />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-end justify-between mb-12">
            <div>
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase mb-4" style={{ backgroundColor: PINK, color: WHITE, fontFamily: "'DM Mono', monospace" }}>
                Tienda y Galería
              </span>
              <h2 className="text-4xl md:text-5xl font-bold" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>
                Arte que puedes llevar contigo
              </h2>
            </div>
            <a href="#" className="hidden md:flex items-center gap-2 text-sm font-medium" style={{ color: MUTED }}>
              Catálogo completo <ArrowUpRight size={14} />
            </a>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
            {[
              { title: "Sin título No. 7", artist: "Marcus Webb", price: "$240.000", image: "https://images.unsplash.com/photo-1549887534-1541e9326347?w=500&h=600&fit=crop&auto=format" },
              { title: "Sistemas Raíz", artist: "Amara K.", price: "$185.000", image: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=500&h=600&fit=crop&auto=format" },
              { title: "Cámara Eco", artist: "Serigrafía Residencia", price: "$45.000", image: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=500&h=600&fit=crop&auto=format" },
              { title: "Fanzine Anual 2024", artist: "Colectivo Platohedro", price: "$18.000", image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=500&h=600&fit=crop&auto=format" },
            ].map((item) => (
              <div key={item.title} className="group cursor-pointer">
                <div className="overflow-hidden rounded-3xl aspect-[5/6] mb-3 transition-all duration-300 group-hover:-translate-y-2" style={{ backgroundColor: CREAM2, boxShadow: `0 4px 16px rgba(26,18,8,0.08)` }}>
                  <img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-sm font-bold" style={{ color: CHARCOAL, fontFamily: "'DM Serif Display', serif" }}>{item.title}</div>
                    <div className="text-xs mt-0.5" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>{item.artist}</div>
                  </div>
                  <div className="text-sm font-bold" style={{ color: PINK, fontFamily: "'DM Mono', monospace" }}>{item.price}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>


      {/* ══════════════════════════════════════════════════════
          VIDEO — WHITE
      ══════════════════════════════════════════════════════ */}
      <section className="relative overflow-hidden py-24 px-6 md:px-10" style={{ backgroundColor: WHITE, borderTop: `1px solid ${BORDER}` }}>
        <Blob color={`${LIME}18`} style={{ width: 300, height: 240, bottom: -40, left: -40, transform: "rotate(15deg)" }} />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-10">
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase mb-4" style={{ backgroundColor: LIME, color: CHARCOAL, fontFamily: "'DM Mono', monospace" }}>
              Míranos
            </span>
            <h2 className="text-4xl md:text-5xl font-bold" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>
              Platohedro en movimiento
            </h2>
          </div>

          <div className="relative aspect-video max-w-4xl mx-auto rounded-3xl overflow-hidden group cursor-pointer" style={{ boxShadow: `0 12px 48px rgba(26,18,8,0.12)`, border: `1px solid ${BORDER}` }}>
            <img src="https://images.unsplash.com/photo-1571260899304-425eee4c7efd?w=1200&h=700&fit=crop&auto=format" alt="Comunidad en el estudio de Platohedro" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
            <div className="absolute inset-0" style={{ background: "rgba(26,18,8,0.28)" }} />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-20 h-20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300" style={{ backgroundColor: LIME, boxShadow: `0 8px 40px rgba(153,204,51,0.5)` }}>
                <Play size={28} className="ml-1" style={{ color: CHARCOAL }} />
              </div>
            </div>
            <div className="absolute bottom-5 left-5 right-5">
              <div className="inline-block rounded-2xl px-4 py-2.5 backdrop-blur-md" style={{ backgroundColor: "rgba(255,255,255,0.92)", border: `1px solid ${BORDER}` }}>
                <p className="text-sm font-bold" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>
                  "Platohedro: Un año en el estudio" — Película anual 2024
                </p>
                <p className="text-xs mt-0.5" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>12 min</p>
              </div>
            </div>
          </div>
        </div>
      </section>


      {/* ══════════════════════════════════════════════════════
          EVENTOS — CREAM
      ══════════════════════════════════════════════════════ */}
      <section className="relative overflow-hidden py-24 px-6 md:px-10" style={{ background: `linear-gradient(145deg, ${CREAM} 0%, ${WHITE} 70%)`, borderTop: `1px solid ${BORDER}` }}>
        <Blob color={`${LIME}22`} style={{ width: 300, height: 240, top: -50, right: 100, transform: "rotate(-12deg)" }} />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex items-end justify-between mb-12">
            <div>
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase mb-4" style={{ backgroundColor: LIME, color: CHARCOAL, fontFamily: "'DM Mono', monospace" }}>
                Próximamente
              </span>
              <h2 className="text-4xl md:text-5xl font-bold" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>
                Eventos y Calendario
              </h2>
            </div>
            <a href="#" className="hidden md:flex items-center gap-2 text-sm font-medium" style={{ color: MUTED }}>
              Calendario completo <ArrowUpRight size={14} />
            </a>
          </div>

          <div style={{ borderTop: `1px solid ${BORDER}` }}>
            {events.map((event) => (
              <div
                key={event.title}
                className="group flex items-center gap-6 py-5 px-3 -mx-3 cursor-pointer transition-all duration-200 rounded-2xl"
                style={{ borderBottom: `1px solid ${BORDER}` }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.backgroundColor = LIME_WASH; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.backgroundColor = "transparent"; }}
              >
                <div className="w-16 text-center shrink-0 rounded-2xl py-2" style={{ backgroundColor: LIME_WASH, border: `1px solid rgba(153,204,51,0.3)` }}>
                  <div className="text-xs font-medium" style={{ color: LIME_DARK, fontFamily: "'DM Mono', monospace" }}>{event.date.month}</div>
                  <div className="text-2xl font-bold leading-tight" style={{ fontFamily: "'DM Serif Display', serif", color: LIME_DARK }}>{event.date.day}</div>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold" style={{ color: CHARCOAL, fontFamily: "'DM Serif Display', serif" }}>{event.title}</h3>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1">
                    <span className="flex items-center gap-1 text-xs" style={{ color: MUTED }}>
                      <MapPin size={10} style={{ color: LIME }} /> {event.location}
                    </span>
                    <span className="flex items-center gap-1 text-xs" style={{ color: MUTED }}>
                      <Calendar size={10} style={{ color: LIME }} /> {event.time}
                    </span>
                  </div>
                </div>
                <div className="shrink-0 flex items-center gap-3">
                  <span
                    className="px-3 py-1 text-xs font-bold rounded-full"
                    style={{
                      fontFamily: "'DM Mono', monospace",
                      backgroundColor: event.tag === "Libre" ? LIME : PINK,
                      color: event.tag === "Libre" ? CHARCOAL : WHITE,
                    }}
                  >
                    {event.tag}
                  </span>
                  <ArrowUpRight size={16} className="hidden md:block" style={{ color: MUTED }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>


      {/* ══════════════════════════════════════════════════════
          ALIADOS — WHITE
      ══════════════════════════════════════════════════════ */}
      <section className="py-20 px-6 md:px-10 relative overflow-hidden" style={{ backgroundColor: WHITE, borderTop: `1px solid ${BORDER}` }}>
        {/* Gradient rule */}
        <div className="max-w-7xl mx-auto mb-14">
          <div className="h-px rounded-full" style={{ background: `linear-gradient(to right, transparent, ${LIME}80, ${PINK}50, transparent)` }} />
        </div>
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <span className="text-xs tracking-widest uppercase font-medium" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>
              Posible gracias a nuestros aliados y financiadores
            </span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {sponsors.map((sponsor) => (
              <div
                key={sponsor.name}
                className="rounded-2xl flex items-center justify-center px-4 py-6 cursor-pointer transition-all hover:-translate-y-0.5 hover:shadow-sm"
                style={{ backgroundColor: CREAM, border: `1px solid ${BORDER}` }}
                title={sponsor.full}
              >
                <span className="text-xs text-center font-semibold" style={{ color: SLATE, fontFamily: "'DM Mono', monospace" }}>{sponsor.name}</span>
              </div>
            ))}
          </div>
          <p className="text-center text-xs mt-6" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>
            ¿Interesado en ser aliado?{" "}
            <a href="#" style={{ color: LIME_DARK, fontWeight: 700 }} className="hover:underline">Escríbenos →</a>
          </p>
        </div>
      </section>


      {/* ══════════════════════════════════════════════════════
          APOYAR — LIME WASH + PINK ACCENTS
      ══════════════════════════════════════════════════════ */}
      <section id="donate" className="relative overflow-hidden py-24 px-6 md:px-10" style={{ background: `linear-gradient(150deg, ${LIME_WASH} 0%, ${WHITE} 50%, ${PINK_WASH} 100%)`, borderTop: `3px solid ${LIME}` }}>
        <Blob color={`${LIME}28`} style={{ width: 440, height: 360, top: -80, left: -80, transform: "rotate(-15deg)" }} />
        <Blob color={`${PINK}20`} style={{ width: 320, height: 260, bottom: -60, right: -60, transform: "rotate(10deg)" }} />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-16">
            <div
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold mb-6"
              style={{ background: `linear-gradient(135deg, ${LIME}30, ${PINK}20)`, color: CHARCOAL, border: `1px solid ${LIME}40` }}
            >
              <Heart size={14} style={{ color: PINK }} /> APOYAR — SOSTÉN EL PROCESO
            </div>
            <h2 className="text-4xl md:text-5xl font-bold mb-4" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>
              Cada aporte sostiene<br />
              <span className="italic" style={{ color: LIME }}>vidas creativas reales.</span>
            </h2>
            <p className="max-w-xl mx-auto leading-relaxed" style={{ color: MUTED }}>
              Tu apoyo va directamente a los programas, residencias y laboratorios de Platohedro en Medellín.
            </p>
          </div>

          {/* Steps */}
          <div className="flex items-center justify-center gap-2 mb-12">
            {[[1, "Elegir monto"], [2, "Tus datos"], [3, "Pago"], [4, "Confirmar"]].map(([step, label], i) => (
              <div key={step as number} className="flex items-center gap-2">
                <button onClick={() => setDonateStep(step as number)} className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all"
                    style={{
                      backgroundColor: donateStep >= (step as number) ? LIME : CREAM2,
                      color: donateStep >= (step as number) ? CHARCOAL : MUTED,
                      fontFamily: "'DM Mono', monospace",
                      boxShadow: donateStep >= (step as number) ? `0 2px 12px rgba(153,204,51,0.35)` : "none",
                    }}
                  >
                    {donateStep > (step as number) ? <CheckCircle size={14} /> : step}
                  </div>
                  <span className="text-xs hidden md:block font-medium" style={{ fontFamily: "'DM Mono', monospace", color: donateStep >= (step as number) ? CHARCOAL : MUTED }}>
                    {label}
                  </span>
                </button>
                {i < 3 && <div className="w-8 md:w-12 h-px mx-1" style={{ backgroundColor: BORDER }} />}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start max-w-5xl mx-auto">
            {/* Tier picker */}
            <div className="rounded-3xl p-6 md:p-8" style={{ backgroundColor: WHITE, border: `1px solid ${BORDER}`, boxShadow: `0 4px 32px rgba(26,18,8,0.06)` }}>
              <h3 className="text-sm font-bold mb-5" style={{ color: CHARCOAL, fontFamily: "'DM Mono', monospace" }}>ELIGE UN NIVEL DE APOYO (COP)</h3>
              <div className="grid grid-cols-2 gap-3 mb-6">
                {donorTiers.map((tier, i) => (
                  <button
                    key={tier.label}
                    onClick={() => { setSelectedTier(i); setCustomAmount(""); }}
                    className="text-left p-4 rounded-2xl border-2 transition-all duration-200"
                    style={{
                      borderColor: selectedTier === i ? LIME : BORDER,
                      backgroundColor: selectedTier === i ? LIME_WASH : CREAM,
                      boxShadow: selectedTier === i ? `0 0 0 1px ${LIME}` : "none",
                    }}
                  >
                    <div className="text-xl font-bold mb-0.5" style={{ fontFamily: "'DM Serif Display', serif", color: LIME_DARK }}>{tier.amount}</div>
                    <div className="text-xs font-bold mb-1" style={{ color: CHARCOAL }}>{tier.label}</div>
                    <div className="text-xs" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>{tier.perks}</div>
                  </button>
                ))}
              </div>

              <div className="mb-5">
                <label className="block text-xs font-bold mb-2" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>O INGRESA UN MONTO PERSONALIZADO (COP)</label>
                <div className="flex items-center rounded-2xl border focus-within:border-lime-400 transition-all" style={{ borderColor: BORDER, backgroundColor: CREAM }}>
                  <span className="px-3 text-sm" style={{ color: MUTED }}>$</span>
                  <input
                    type="number"
                    placeholder="Otro monto"
                    value={customAmount}
                    onChange={(e) => { setCustomAmount(e.target.value); setSelectedTier(-1); }}
                    className="flex-1 bg-transparent py-3 pr-4 text-sm focus:outline-none"
                    style={{ color: CHARCOAL }}
                  />
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-xs font-bold mb-2" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>FRECUENCIA</label>
                <div className="flex rounded-2xl overflow-hidden" style={{ border: `1px solid ${BORDER}`, backgroundColor: CREAM }}>
                  {["Una vez", "Mensual", "Anual"].map((freq, i) => (
                    <button
                      key={freq}
                      className="flex-1 py-2.5 text-xs font-bold transition-colors"
                      style={{
                        fontFamily: "'DM Mono', monospace",
                        borderRight: i < 2 ? `1px solid ${BORDER}` : "none",
                        backgroundColor: i === 0 ? LIME : "transparent",
                        color: i === 0 ? CHARCOAL : MUTED,
                      }}
                    >
                      {freq}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => setDonateStep(2)}
                className="group w-full flex items-center justify-between px-6 py-4 rounded-2xl font-bold transition-all hover:scale-[1.01]"
                style={{ backgroundColor: LIME, color: CHARCOAL, boxShadow: `0 4px 20px rgba(153,204,51,0.35)` }}
              >
                <span className="flex items-center gap-2">
                  <CreditCard size={16} /> Continuar al pago
                </span>
                <ArrowUpRight size={16} />
              </button>
              <p className="text-xs mt-3 text-center" style={{ color: MUTED, fontFamily: "'DM Mono', monospace" }}>
                🔒 Pago seguro · Platohedro, Medellín, Colombia
              </p>
            </div>

            {/* Impact */}
            <div className="space-y-4">
              <div className="rounded-3xl p-6" style={{ backgroundColor: WHITE, border: `1px solid ${BORDER}` }}>
                <h3 className="font-bold mb-4" style={{ fontFamily: "'DM Serif Display', serif", color: CHARCOAL }}>¿Qué hace posible tu aporte?</h3>
                <div className="space-y-3">
                  {[
                    [Users, "$50k cubre materiales para un niñe durante un mes"],
                    [CheckCircle, "$150k financia una sesión de taller para 8 jóvenes"],
                    [Heart, "$300k sostiene una semana de residencia artística"],
                    [ArrowUpRight, "$1M patrocina una beca de residencia completa"],
                  ].map(([Icon, text], i) => (
                    <div key={i} className="flex items-start gap-3 text-sm" style={{ color: MUTED, opacity: selectedTier >= i || selectedTier === -1 ? 1 : 0.4, transition: "opacity 0.3s" }}>
                      <span className="mt-0.5 shrink-0" style={{ color: LIME }}>
                        {/* @ts-ignore */}
                        <Icon size={14} />
                      </span>
                      {text}
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-3xl p-6" style={{ backgroundColor: LIME_WASH, border: `1px solid rgba(153,204,51,0.3)` }}>
                <h3 className="font-bold mb-4" style={{ fontFamily: "'DM Serif Display', serif", color: LIME_DARK }}>Cómo donar →</h3>
                <ol className="space-y-3">
                  {[
                    "Elige un nivel de apoyo o ingresa un monto libre arriba.",
                    "Selecciona la frecuencia: única, mensual o anual.",
                    "Ingresa tus datos de contacto y pago.",
                    "Revisa y confirma tu aporte.",
                    "Recibirás un comprobante por correo en minutos.",
                  ].map((step, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm" style={{ color: SLATE }}>
                      <span className="w-5 h-5 rounded-full text-xs flex items-center justify-center shrink-0 mt-0.5 font-bold" style={{ backgroundColor: LIME, color: CHARCOAL }}>
                        {i + 1}
                      </span>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>

              <div className="rounded-3xl p-5 text-sm" style={{ backgroundColor: PINK_WASH, border: `1px solid rgba(255,70,162,0.2)` }}>
                <h4 className="font-bold mb-3 text-xs tracking-widest uppercase" style={{ color: PINK, fontFamily: "'DM Mono', monospace" }}>Otras formas de apoyar</h4>
                <div className="space-y-2" style={{ color: MUTED }}>
                  <p><span className="font-bold" style={{ color: CHARCOAL }}>Transferencia:</span> Nequi / Bancolombia — donaciones@platohedro.org</p>
                  <p><span className="font-bold" style={{ color: CHARCOAL }}>Especie:</span> Materiales, equipo o tiempo — escríbenos</p>
                  <p><span className="font-bold" style={{ color: CHARCOAL }}>Voluntariado:</span> Únete a nuestros procesos comunitarios</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>


      {/* ══════════════════════════════════════════════════════
          FOOTER — WARM CHARCOAL
      ══════════════════════════════════════════════════════ */}
      <footer className="px-6 md:px-10 py-14" style={{ backgroundColor: CHARCOAL }}>
        {/* Lime-to-pink rule at top of footer */}
        <div className="max-w-7xl mx-auto mb-10">
          <div className="h-px rounded-full mb-10" style={{ background: `linear-gradient(to right, ${LIME}, ${CREAM2}40, ${PINK})` }} />
        </div>

        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-10 mb-10">
          <div>
            <div className="flex items-center gap-2 mb-5">
              <div className="w-9 h-9 rounded-xl overflow-hidden p-1" style={{ backgroundColor: "#7dcfca" }}>
                <ImageWithFallback src={logoImg} alt="Platohedro" className="w-full h-full object-contain" />
              </div>
              <span className="font-bold tracking-widest uppercase text-sm text-white" style={{ fontFamily: "'DM Mono', monospace" }}>Platohedro</span>
            </div>
            <p className="text-xs leading-relaxed" style={{ color: "#8C7B6B", fontFamily: "'DM Mono', monospace" }}>
              Organización cultural<br />Medellín, Colombia<br />Fundada en 2004
            </p>
          </div>

          {[
            ["Programas", ["Educación Artística", "Lab Digital", "Narrativas", "Música", "Residencias"]],
            ["Organización", ["Sobre Platohedro", "Arte y Pensamiento", "Tecnología", "Tienda / Galería", "Prensa"]],
            ["Contacto", ["Escríbenos", "Apoyar", "Voluntariado", "Boletín", "Instagram"]],
          ].map(([heading, links]) => (
            <div key={heading as string}>
              <h4 className="text-xs font-bold text-white mb-4 tracking-widest uppercase" style={{ fontFamily: "'DM Mono', monospace" }}>{heading}</h4>
              <ul className="space-y-2.5">
                {(links as string[]).map((link) => (
                  <li key={link}>
                    <a href="#" className="text-xs transition-colors hover:text-white" style={{ color: "#6B5E52", fontFamily: "'DM Mono', monospace" }}>{link}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="max-w-7xl mx-auto pt-8 flex flex-col md:flex-row items-center justify-between gap-4" style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <p className="text-xs" style={{ color: "#6B5E52", fontFamily: "'DM Mono', monospace" }}>
            © 2025 Platohedro. Medellín, Colombia.
          </p>
          <div className="flex gap-6 text-xs" style={{ fontFamily: "'DM Mono', monospace" }}>
            {["Política de privacidad", "Términos de uso", "Accesibilidad"].map((item) => (
              <a key={item} href="#" className="transition-colors hover:text-white" style={{ color: "#6B5E52" }}>{item}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
